ALTER TABLE top_salaries ADD (createdBy VARCHAR(30), dateCreated TIMESTAMP, modifiedBy VARCHAR(30), dateModified TIMESTAMP); 
