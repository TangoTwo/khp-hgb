//
// Created by khp on 07.01.19.
//

#include <ml5/ml5.h>
#include <iostream>

int main() {
    ml5::string helloMag("Hello ML5");

    std::cout << helloMag << std::endl;
}