//
// Created by khp on 16.12.18.
//

#ifndef CHESS_GAMEMODES_H
#define CHESS_GAMEMODES_H

void clearCmd();

void multiplayerGame();

void simulatedGame();

#endif //CHESS_GAMEMODES_H
