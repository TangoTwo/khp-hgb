//
// Created by khp on 24.11.18.
//

#ifndef PROJECT_RANDOM_H
#define PROJECT_RANDOM_H

#include "types.h"

extern color random_color(void);
extern form random_form(void);

#endif //PROJECT_RANDOM_H
