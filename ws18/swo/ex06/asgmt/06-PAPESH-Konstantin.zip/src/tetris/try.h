//
// Created by khp on 24.11.18.
//

#ifndef PROJECT_TRY_H
#define PROJECT_TRY_H

#include "types.h"
#include <stdbool.h>

extern bool try_move(int , int , form*);
extern bool try_rotate(form*);
#endif //PROJECT_TRY_H
