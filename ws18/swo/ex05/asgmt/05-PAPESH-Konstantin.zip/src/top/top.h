//
// Created by khp on 08.11.18.
//

#ifndef PROJECT_TOP_H
#define PROJECT_TOP_H

#include "../adt/al_adt.h"

adtPtr_t topological_sort(adtPtr_t);

#endif //PROJECT_TOP_H
